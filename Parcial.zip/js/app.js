var loginForm = document.getElementById("formulario-login");
var loginError = document.getElementById("error-login");
var claveSesion = "sesion-docente";

loginForm.addEventListener("submit", function (event) {
  event.preventDefault();

  var email = document.getElementById("correo").value.trim().toLowerCase();
  var password = document.getElementById("contrasena").value;

  if (email.length > 0 && password.length > 0) {
    loginError.classList.add("oculto");
    guardarSesion(email);
    mostrarApp();
  } else {
    loginError.classList.remove("oculto");
  }
});

function guardarSesion(email) {
  try {
    localStorage.setItem(claveSesion, JSON.stringify({ correo: email }));
  } catch (err) {
    console.error("No se pudo guardar la sesión", err);
  }
}

function borrarSesion() {
  try {
    localStorage.removeItem(claveSesion);
  } catch (err) {
    console.error("No se pudo borrar la sesión", err);
  }
}

function revisarSesionGuardada() {
  try {
    var guardado = localStorage.getItem(claveSesion);
    if (guardado) {
      var datos = JSON.parse(guardado);
      if (datos.correo) {
        mostrarApp();
      }
    }
  } catch (err) {}
}

revisarSesionGuardada();

function mostrarApp() {
  document.getElementById("pantalla-login").classList.add("oculto");
  document.getElementById("aplicacion").classList.remove("oculto");

  cargarDatosDocente();
  cargarInicio();
  cargarAsignaturas();
  cargarHorario();
  cargarPerfil();
  irAPagina("inicio");
}

document.getElementById("boton-cerrar-sesion").addEventListener("click", function () {
  borrarSesion();
  document.getElementById("aplicacion").classList.add("oculto");
  document.getElementById("pantalla-login").classList.remove("oculto");
  loginForm.reset();
  cerrarMenu();
});

function cargarDatosDocente() {
  document.getElementById("nombre-usuario").textContent = docente.nombre;
  document.getElementById("avatar-usuario").textContent = docente.iniciales;
  document.getElementById("avatar-barra-lateral").textContent = docente.iniciales;
  document.getElementById("nombre-barra-lateral").textContent = docente.nombre;
  document.getElementById("correo-barra-lateral").textContent = docente.correo;
}

var menuBtn = document.getElementById("boton-menu");
var sidebar = document.getElementById("barra-lateral");
var sidebarOverlay = document.getElementById("superposicion-barra-lateral");

function abrirMenu() {
  sidebar.classList.add("abierto");
  sidebarOverlay.classList.add("visible");
  menuBtn.classList.add("abierto");
}

function cerrarMenu() {
  sidebar.classList.remove("abierto");
  sidebarOverlay.classList.remove("visible");
  menuBtn.classList.remove("abierto");
}

menuBtn.addEventListener("click", function () {
  if (sidebar.classList.contains("abierto")) {
    cerrarMenu();
  } else {
    abrirMenu();
  }
});

sidebarOverlay.addEventListener("click", cerrarMenu);

var links = document.querySelectorAll("[data-page]");
for (var i = 0; i < links.length; i++) {
  links[i].addEventListener("click", function () {
    irAPagina(this.getAttribute("data-page"));
  });
}

function irAPagina(nombre) {
  var pages = document.querySelectorAll(".pagina");
  for (var i = 0; i < pages.length; i++) {
    pages[i].classList.add("oculto");
  }
  document.getElementById("pagina-" + nombre).classList.remove("oculto");

  var menuLinks = document.querySelectorAll(".enlace-menu");
  for (var i = 0; i < menuLinks.length; i++) {
    if (menuLinks[i].getAttribute("data-page") === nombre) {
      menuLinks[i].classList.add("activo");
    } else {
      menuLinks[i].classList.remove("activo");
    }
  }

  window.scrollTo(0, 0);
  cerrarMenu();
}

function cargarInicio() {
  document.getElementById("estadistica-asignaturas").textContent = asignaturas.length;
  document.getElementById("estadistica-clases").textContent = horario.length;

  var lista = document.getElementById("proximas-clases");
  lista.innerHTML = "";

  var ordenadas = horario.slice().sort(function (a, b) {
    if (a.dia !== b.dia) return a.dia - b.dia;
    return a.horaInicio - b.horaInicio;
  });

  var vistos = [];
  var proximas = [];
  for (var i = 0; i < ordenadas.length; i++) {
    if (vistos.indexOf(ordenadas[i].codigo) === -1) {
      vistos.push(ordenadas[i].codigo);
      proximas.push(ordenadas[i]);
    }
    if (proximas.length === 3) break;
  }

  for (var i = 0; i < proximas.length; i++) {
    var clase = proximas[i];
    var asignatura = buscarAsignatura(clase.codigo);

    var item = document.createElement("div");
    item.className = "elemento-clase";
    item.setAttribute("data-codigo", asignatura.codigo);
    item.innerHTML =
      '<div class="dia-clase">' + nombresDiasCortos[clase.dia] + '</div>' +
      '<div class="info-clase">' +
        '<h4>' + asignatura.nombre + '</h4>' +
        '<p>' + nombresDias[clase.dia] + ' - ' + formatearHora(clase.horaInicio) + ' - ' + formatearHora(clase.horaFin) + ' ' + clase.sala + '</p>' +
      '</div>';

    item.addEventListener("click", function () {
      abrirModal(this.getAttribute("data-codigo"));
    });
    lista.appendChild(item);
  }
}

function cargarAsignaturas(filtro) {
  filtro = filtro || "";
  var grid = document.getElementById("cuadricula-asignaturas");
  var noResults = document.getElementById("sin-resultados");
  grid.innerHTML = "";

  var texto = filtro.trim().toLowerCase();
  var filtradas = [];

  for (var i = 0; i < asignaturas.length; i++) {
    var a = asignaturas[i];
    if (a.nombre.toLowerCase().indexOf(texto) !== -1 || a.codigo.toLowerCase().indexOf(texto) !== -1) {
      filtradas.push(a);
    }
  }

  if (filtradas.length === 0) {
    noResults.classList.remove("oculto");
  } else {
    noResults.classList.add("oculto");
  }

  for (var i = 0; i < filtradas.length; i++) {
    var asignatura = filtradas[i];
    var numClases = contarClasesPorCodigo(asignatura.codigo);

    var card = document.createElement("div");
    card.className = "tarjeta-asignatura";
    card.setAttribute("data-codigo", asignatura.codigo);
    card.innerHTML =
      '<span class="codigo-asignatura">' + asignatura.codigo + '</span>' +
      '<h4>' + asignatura.nombre + '</h4>' +
      '<div class="meta-asignatura">' +
        '<span>' + asignatura.sala + '</span>' +
        '<span>' + numClases + ' Clases Por Semana</span>' +
        '<span>Creditos: ' + asignatura.creditos + '</span>' +
      '</div>';

    card.addEventListener("click", function () {
      abrirModal(this.getAttribute("data-codigo"));
    });
    grid.appendChild(card);
  }
}

document.getElementById("entrada-busqueda").addEventListener("input", function (event) {
  cargarAsignaturas(event.target.value);
});

var modalOverlay = document.getElementById("superposicion-modal");

function abrirModal(codigo) {
  var asignatura = buscarAsignatura(codigo);
  var clasesDeEsta = horario.filter(function (h) {
    return h.codigo === codigo;
  }).sort(function (a, b) {
    return a.dia - b.dia;
  });

  document.getElementById("titulo-modal").textContent = asignatura.nombre;
  document.getElementById("creditos-modal").textContent = "Creditos: " + asignatura.creditos;

  var body = document.getElementById("cuerpo-modal");
  var html = "";

  for (var i = 0; i < clasesDeEsta.length; i++) {
    var c = clasesDeEsta[i];
    html += '<div class="fila-modal">' +
      nombresDias[c.dia] + ' ' + formatearHora(c.horaInicio) + ' - ' + formatearHora(c.horaFin) +
    '</div>' +
    '<div class="divisor-modal"></div>';
  }

  body.innerHTML = html;
  modalOverlay.classList.add("visible");
}

document.getElementById("cerrar-modal").addEventListener("click", function () {
  modalOverlay.classList.remove("visible");
});

modalOverlay.addEventListener("click", function (event) {
  if (event.target === modalOverlay) {
    modalOverlay.classList.remove("visible");
  }
});

function cargarHorario() {
  var tabla = document.getElementById("tabla-horario");

  var html = "<thead><tr><th class='pildora-hora'>HORA</th>";
  for (var dia = 1; dia <= 5; dia++) {
    var claseHeader = (dia % 2 === 1) ? "pildora-naranja" : "pildora-blanca";
    html += "<th class='" + claseHeader + "'>" + nombresDias[dia].toUpperCase() + "</th>";
  }
  html += "</tr></thead><tbody>";

  for (var h = 0; h < horasHorario.length; h++) {
    var hora = horasHorario[h];
    html += "<tr><td class='columna-hora'>" + formatearHora(hora) + "</td>";

    for (var dia = 1; dia <= 5; dia++) {
      var entrada = null;
      for (var i = 0; i < horario.length; i++) {
        var e = horario[i];
        if (e.dia === dia && hora >= e.horaInicio && hora < e.horaFin) {
          entrada = e;
          break;
        }
      }

      if (entrada) {
        var asignatura = buscarAsignatura(entrada.codigo);
        html += "<td><div class='bloque-horario insignia-" + asignatura.color + "' data-codigo='" + entrada.codigo + "'>" +
          "<strong>" + asignatura.codigo + "</strong>" +
          "<span>" + entrada.sala + "</span>" +
        "</div></td>";
      } else {
        html += "<td></td>";
      }
    }
    html += "</tr>";
  }

  html += "</tbody>";
  tabla.innerHTML = html;

  var bloques = tabla.querySelectorAll(".bloque-horario");
  for (var i = 0; i < bloques.length; i++) {
    bloques[i].addEventListener("click", function () {
      abrirModal(this.getAttribute("data-codigo"));
    });
  }
}

function cargarPerfil() {
  document.getElementById("avatar-perfil").textContent = docente.iniciales;
  document.getElementById("nombre-perfil").textContent = docente.nombreCompleto;
  document.getElementById("facultad-perfil").textContent = docente.facultad;
  document.getElementById("valor-nombre-perfil").textContent = docente.nombreCompleto;
  document.getElementById("valor-correo-perfil").textContent = docente.correo;
  document.getElementById("valor-facultad-perfil").textContent = docente.facultad;
  document.getElementById("valor-asignaturas-perfil").textContent = asignaturas.length;
}
